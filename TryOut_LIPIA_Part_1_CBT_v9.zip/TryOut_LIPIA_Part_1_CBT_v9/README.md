# Try Out LIPIA Part 1 — CBT Web Application (Versi Lengkap)
Dipersembahkan oleh: **Abu Aiman Penerjemah Tersumpah**

Aplikasi web Computer-Based Test (CBT) mandiri untuk simulasi persiapan Ujian Masuk LIPIA Jakarta (76 Butir Soal Terstruktur).

---

## 🔑 KODE AKSES UJIAN
Untuk memulai pengerjaan try out, peserta wajib memasukkan:
**Kode Akses:** `abu aiman penerjemah` (bebas huruf besar/kecil)

---

## 🎧 PEMETAAN KATEGORI SOAL (76 BUTIR)
- **Bagian A: Fahmul Masmu' (Menyimak) — 17 Soal**:
  - Soal 1 s.d. 10: `01.wav` s.d. `10.wav` (Huruf dan kata tunggal)
  - Soal 11 s.d. 13: `11.wav` (Kisah Budi)
  - Soal 17 s.d. 20: `17.wav` (Biografi Syaikh Muhammad bin Abdul Wahhab)
- **Bagian B: Fahmul Maqru' (Membaca & Pemahaman) — 23 Soal**:
  - Soal 14 s.d. 16: Pemahaman umum langsung (**tanpa panel audio**)
  - Soal 21 s.d. 40: Teks bacaan *Al-Mu'min Ash-Shalih* (dilengkapi kartu naskah bacaan)
- **Bagian C: Qawa'id — 25 Soal** (Soal 41 s.d. 65): Tata bahasa Nahwu dan Sharaf pilihan ganda
- **Bagian D: Ta'bir — 11 Soal** (Soal 66 s.d. 76): **Interaktif Drag & Drop Paragraf Rumpang**
  - Mengisi 11 titik kosong (الفراغ) pada teks narasi lengkap dengan cara menarik (*drag & drop*) atau mengetuk (*click to place*) kata pilihan dari Bank Kata (12 kata).
  - Dilengkapi tombol reset isian, pendeteksi kata terpakai, dan pembahasan komprehensif saat ujian selesai.

---

## 🎓 FITUR SERTIFIKAT (EKSPOR PDF, PNG, JPG & CETAK)
- Logo vektor Abu Aiman dan tanda tangan resmi M. Tigar Abdillah tertanam permanen dan otentik pada sertifikat kelulusan/simulasi.
- Disediakan tombol ekspor lengkap:
  1. **📄 Unduh PDF** (`html2pdf.js`)
  2. **🖼️ Unduh PNG** (Gambar beresolusi tajam)
  3. **🖼️ Unduh JPG** (Gambar beresolusi tinggi)
  4. **🖨️ Cetak** (Dialog printer cetak langsung)

---

## ⚠️ PEMBERITAHUAN PENTING (DISCLAIMER)
Website ini merupakan sarana **simulasi latihan mandiri (Try Out)** dan **BUKAN merupakan ujian resmi yang diselenggarakan oleh pihak LIPIA (Lembaga Ilmu Pengetahuan Islam dan Arab) Jakarta** maupun Universitas Islam Imam Muhammad bin Saud.
